# James Zhu — a little desktop

A dependency-free personal website inspired by early Macintosh interfaces. Includes a CSS 3D scroll-controlled laptop, spring-return draggable windows, responsive layouts, accessible native dialogs, and a real Spotify embed.

## Run locally

Requires Node.js. From this directory run `node serve.mjs`, then open http://127.0.0.1:4173.

## Personalize

Edit `dist/config.json` to change the display name, subtitle, Spotify selection, or quotes for all visitors. Social and email links live in `dist/index.html`.

The music and note dialogs save preferences only in the current browser. File → Export preferences downloads a replacement `config.json`; replace the file in `dist/` and republish to change shared defaults. Private browsing or blocked storage may keep changes only for the visit.

The supplied Christina Koch quote is reproduced from the owner’s provided content. No additional third-party quotations were invented.

## Design and access

Uses locally installed SF Pro or the native Apple system font on Apple devices, with Helvetica Neue / Arial fallbacks elsewhere. Monospace accents use SF Mono / Menlo / Monaco when available; no Apple font binaries are redistributed. The desktop cursor is an original Mac-inspired SVG.

The native desktop layout becomes a single-column stack on phones. Only window title bars capture drag gestures, leaving page scrolling and links available. The lid animation responds to normal downward scroll (swipe up on touch). Reduced-motion mode bypasses it, and Skip intro is available to everyone.

Spotify is the only third-party embedded content, and loads on entering the desktop. Playback, availability, authentication and regional restrictions are controlled by Spotify; the site does not autoplay music. Official embed documentation: https://developer.spotify.com/documentation/embeds/tutorials/creating-an-embed

The Site has been registered for private hosting, but has not been deployed. The current session's approval policy blocked the required source-upload helper. The owner must also enable public access before distributing it as a public link page.

## Verification

JavaScript syntax, unique HTML IDs, ARIA targets, icon and dialog references, script targets, the five supplied profile/contact URLs, Spotify URL validation, quote limits, and spring convergence at 30/60/120 Hz passed code-level checks. The default Peaceful Piano playlist URL was checked against Spotify.

Interactive browser and screenshot checks remain unverified: local network preview requests failed, and the browser tool's URL policy rejected file URLs. Device rendering, actual Spotify playback, and the animation's visual smoothness still need a real-browser check.
